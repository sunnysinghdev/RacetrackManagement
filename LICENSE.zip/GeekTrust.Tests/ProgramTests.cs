﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace GeekTrust.Tests
{
    public class ProgramTests
    {
        [Test]
        public void TestProcessing()
        {
        }
    }
}
