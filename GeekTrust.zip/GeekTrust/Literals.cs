namespace GeekTrust
{
    public static class Literals 
        {
        public const string BOOK = "BOOK"; 
        public const string ADDITIONAL = "ADDITIONAL"; 
        public const string CAR = "CAR"; 
        public const string BIKE = "BIKE"; 
        public const string SUV = "SUV"; 
        public const string REGULAR = "REGULAR"; 
        public const string VIP = "VIP"; 
        public const string SUCCESS = "SUCCESS"; 
        public const string RACETRACK_FULL  = "RACETRACK_FULL"; 
        public const string INVALID_ENTRY_TIME  = "INVALID_ENTRY_TIME"; 
        public const string INVALID_EXIT_TIME = "INVALID_EXIT_TIME";  
        public const string VIP_CAR = "VIP_CAR";  
        public const string VIP_SUV = "VIP_SUV";  
        public const string REVENUE = "REVENUE";             
    }
}